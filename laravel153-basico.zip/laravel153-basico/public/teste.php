<!DOCTYPE html>
<html>
<body>

<?php
echo "Consegui executar um PHP no localhost POHAAAAA";
?>

</body>
</html>