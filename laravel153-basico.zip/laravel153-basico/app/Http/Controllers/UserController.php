<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class UserController extends Controller
{
    /**
     * Show a list of all of the application's users.
     *
     * @return Response
     */
    public function index()
    {
        //INSERTS
        DB::insert('insert into users (id, name) values (?, ?)', [1, 'Dayle']);
        DB::insert('insert into users (id, name) values (?, ?)', [2, 'John']);

        $users = DB::select('select * from users where active = ?', [1]);

        $results = DB::select('select * from users where id = :id', ['id' => 1]);

        $deleted = DB::delete('delete from users');

        foreach ($users as $user) {
            echo $user->name;
        }

        return view('user.index', ['users' => $users]);
    }
}